﻿from PIL import Image
import numpy as np
import os

img_name = input("输入要转换的图片完整文件名（包含文件类型）：")  # input image absolute path,containing file type
img_width = int(input("输入生成的图片宽度:"))  # input image width
img_height = int(input("输入生成的图片高度:"))  # input image height
path = os.getcwd() + "\\"
color_map = np.load(path + "color_map.npy")
color_map = color_map.tolist()
color_list = np.load(path + "color_list.bin.npy")
color_list = color_list.tolist()
img = Image.open(path + img_name)
Image._show(img)
img = img.resize((img_width, img_height))
size = img.size
img_array = np.asarray(img)
width = size[0]
height = size[1]
img_result = np.zeros(shape=(height, width, 3), dtype=np.uint8)
for v0 in range(height):
    for v1 in range(width):
        if (img_array[v0][v1][0] == img_array[v0][v1][1] == img_array[v0][v1][2] == 0) or (
                img_array[v0][v1][0] == img_array[v0][v1][1] == img_array[v0][v1][2] == 255):
            img_result[v0][v1][0] = 0
            img_result[v0][v1][1] = 0
            img_result[v0][v1][2] = 0
        else:
            index = color_map[img_array[v0][v1][0]][img_array[v0][v1][1]][img_array[v0][v1][2]]
            img_result[v0][v1][0] = color_list[index][0]
            img_result[v0][v1][1] = color_list[index][1]
            img_result[v0][v1][2] = color_list[index][2]
img = Image.fromarray(img_result)
Image._show(img)
img.save(path + "result.bmp")
