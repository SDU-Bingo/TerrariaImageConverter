from PIL import Image
import numpy as np
import os

img_name = input("输入要转换的图片完整文件名（包含文件类型）：")  # input image absolute path,containing file type
path = os.getcwd() + "\\"
img = Image.open(path + img_name)
size = img.size
img_array = np.asarray(img)
width = size[0]
height = size[1]
img_result = np.zeros(shape=(height, width, 3), dtype=np.uint8)
for v0 in range(height):
    for v1 in range(width):
        if img_array[v0][v1][0] < 40 and img_array[v0][v1][1] < 40 and img_array[v0][v1][2] < 40:
            img_result[v0][v1][0] = img_result[v0][v1][1] = img_result[v0][v1][2] = 128
        if img_array[v0][v1][0] > 215 and img_array[v0][v1][1] > 215 and img_array[v0][v1][2] > 215:
            img_result[v0][v1][0] = img_result[v0][v1][1] = img_result[v0][v1][2] = 0
img = Image.fromarray(img_result)
Image._show(img)
img.save(path + "preprocessed.bmp")
